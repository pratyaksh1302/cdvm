[DscLocalConfigurationManager()]
Configuration ISVBoxConfig
{
    param
    (
        [string]$RegistrationUrl,
        [string]$RegistrationKey,
        [int]$RefreshFrequencyMins,
        [int]$ConfigurationModeFrequencyMins,
        [string]$ConfigurationMode,
        [string]$NodeConfigurationName,
        [boolean]$RebootNodeIfNeeded,
        [string]$ActionAfterReboot,
        [boolean]$AllowModuleOverwrite
    )

    Settings
    {
        RefreshFrequencyMins = $RefreshFrequencyMins
        RefreshMode = "Pull"
        ConfigurationMode = $ConfigurationMode
        AllowModuleOverwrite  = $AllowModuleOverwrite
        RebootNodeIfNeeded = $RebootNodeIfNeeded
        ActionAfterReboot = $ActionAfterReboot
        ConfigurationModeFrequencyMins = $ConfigurationModeFrequencyMins
    }

    ConfigurationRepositoryWeb ConfigurationManager
    {
        ServerURL = $RegistrationUrl   
        RegistrationKey = $RegistrationKey   
        ConfigurationNames = @($NodeConfigurationName)
    }     
        
    ResourceRepositoryWeb ResourceManager
    {
        ServerUrL = $RegistrationUrl
        RegistrationKey = $RegistrationKey 
    }
  
    ReportServerWeb ReportManager
    {
        ServerUrL = $RegistrationUrl
        RegistrationKey = $RegistrationKey 
    }       
}